const baseUrl = "http://localhost:8080/api/customer";

// ==========================
// REGISTER FUNCTIONALITY
// ==========================
document.getElementById("registerForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
    balance: 0
  };

  try {
    const res = await fetch(`${baseUrl}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.ok) {
      alert("Registration successful: " + result.name);
      window.location.href = "login.html";
    } else {
      alert("Registration failed");
    }
  } catch (error) {
    alert("Error: " + error.message);
  }
});

// ==========================
// LOGIN FUNCTIONALITY
// ==========================
document.getElementById("loginForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    email: document.getElementById("loginEmail").value,
    password: document.getElementById("loginPassword").value
  };

  try {
    const res = await fetch(`${baseUrl}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.ok && result.id) {
      localStorage.setItem("user", JSON.stringify(result));
      window.location.href = "dashboard.html";
    } else {
      alert("Invalid credentials");
    }
  } catch (error) {
    alert("Login error: " + error.message);
  }
});

// ==========================
// LOAD DASHBOARD USER DATA
// ==========================
window.onload = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  if (user && document.getElementById("welcomeMsg")) {
    document.getElementById("welcomeMsg").innerText = `Welcome, ${user.name}`;
    document.getElementById("balance").innerText = user.balance;
  }
};

// ==========================
// DEPOSIT FUNCTION
// ==========================
async function deposit() {
  const amount = parseFloat(document.getElementById("amount").value);
  const user = JSON.parse(localStorage.getItem("user"));

  try {
    const res = await fetch(`${baseUrl}/deposit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, amount: amount })
    });

    const result = await res.json();
    if (res.ok) {
      localStorage.setItem("user", JSON.stringify(result));
      document.getElementById("balance").innerText = result.balance;
      alert("Amount deposited successfully!");
    }
  } catch (error) {
    alert("Error during deposit: " + error.message);
  }
}

// ==========================
// WITHDRAW FUNCTION
// ==========================
async function withdraw() {
  const amount = parseFloat(document.getElementById("amount").value);
  const user = JSON.parse(localStorage.getItem("user"));

  try {
    const res = await fetch(`${baseUrl}/withdraw`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, amount: amount })
    });

    const result = await res.json();
    if (res.ok && result.balance !== undefined) {
      localStorage.setItem("user", JSON.stringify(result));
      document.getElementById("balance").innerText = result.balance;
      alert("Withdrawal successful!");
    } else {
      alert("Insufficient balance or error occurred.");
    }
  } catch (error) {
    alert("Error during withdrawal: " + error.message);
  }
}
